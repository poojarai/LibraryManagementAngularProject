import { Component, OnInit } from '@angular/core';
//import { RouterModule } from '@angular/router';
@Component({
  selector: 'app-view-part',
  templateUrl: './view-part.component.html',
  styleUrls: ['./view-part.component.css']
})
export class ViewPartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
