import {
	Component, OnInit, AfterViewInit
}
from '@angular/core';

import {
	CarService
}
from '../carService.service';
import {
	DropdownModule
}
from 'primeng/primeng';
import {
	DataTableModule, SharedModule, DialogModule, Column, Schedule, Growl, Message,ButtonModule, Dropdown
}
from 'primeng/primeng';
import {
	SelectItem
}
from 'primeng/primeng';@
Component({
	selector: 'app-prime-ng',
	templateUrl: './prime-ng.component.html',
	styleUrls: ['./prime-ng.component.css'],
	providers: [CarService]
})
export class PrimeNgComponent implements OnInit {
	carData = [];
	selectedValues: string[] = ['New York'];
	brands: SelectItem[];
	dataTypeOptions: SelectItem[];
	columns: SelectItem[];
	selectedCircle: string;
	selectedCities: any;
	loading: boolean;
	hideNameCol: boolean;
	hideGenderCol: boolean;
	hideCompanyCol: boolean;
	patternForString : string;
	patternForNumber :string;
	constructor(public carService: CarService) {
		this.loading = true;
		carService.getCarsData().subscribe(myData => {
			this.carData = myData;
			this.loading = false;
		});
		this.selectedCircle = "build";
		
		this.brands = [];
		this.brands.push({label: 'All Brands',value: null});
		this.brands.push({label: 'Male',value: 'male'});
		this.brands.push({label: 'Female',value: 'female'});

		this.dataTypeOptions = [];
		this.dataTypeOptions.push({label: 'Select',value: null});
		this.dataTypeOptions.push({label: 'String',value: "string"});
		this.dataTypeOptions.push({label: 'Number',value: "number"});
		this.dataTypeOptions.push({label: 'Boolean',value: "boolean"});
		

		this.columns = [];
		this.columns.push({label: 'Name',value: 'name'});
		this.columns.push({label: 'Gender',value: 'gender'});
		this.columns.push({label: 'Company',value: 'compnay'});
	}
	getColor = function(_c) {
		if(_c == "high") {
			return "red";
		} else if(_c == "low") {
			return "green";
		} else if(_c == "medium") {
			return "orange";
		}
	}
	func = function() {
		// console.log("Hello Pooja");
		//console.log("Ayushi")
		return "newClass";
	}
	onUserChange = function(e) {
		this.hideNameCol = false;
		this.hideGenderCol = false;
		this.hideCompanyCol = false;
		if(this.selectedCities.length == 1) {
			if(((this.selectedCities).indexOf("name")) != -1) {
				this.hideNameCol = false;
				this.hideGenderCol = true;
				this.hideCompanyCol = true;
			} else if(((this.selectedCities).indexOf("gender")) != -1) {
				this.hideGenderCol = false;
				this.hideNameCol = true;
				this.hideCompanyCol = true;
			} else if(((this.selectedCities).indexOf("compnay")) != -1) {
				this.hideCompanyCol = false;
				this.hideNameCol = true;
				this.hideGenderCol = true;
			} else {
				this.hideNameCol = false;
				this.hideGenderCol = false;
				this.hideCompanyCol = false;
			}
		} else if(this.selectedCities.length == 2) {
			if(((this.selectedCities).indexOf("name")) != -1 && ((this.selectedCities).indexOf("gender")) != -1) {
				this.hideNameCol = false;
				this.hideGenderCol = false;
				this.hideCompanyCol = true;
			} else if(((this.selectedCities).indexOf("name")) != -1 && ((this.selectedCities).indexOf("compnay")) != -1) {
				this.hideNameCol = false;
				this.hideCompanyCol = false;
				this.hideGenderCol = true;
			} else if(((this.selectedCities).indexOf("gender")) != -1 && ((this.selectedCities).indexOf("compnay")) != -1) {
				this.hideCompanyCol = false;
				this.hideGenderCol = false;
				this.hideNameCol = true;
			}
		} else if(this.selectedCities.length == 3) {
			if(((this.selectedCities).indexOf("name")) != -1 && ((this.selectedCities).indexOf("gender")) != -1 && ((this.selectedCities).indexOf("compnay")) != -1) {
				this.hideNameCol = false;
				this.hideGenderCol = false;
				this.hideCompanyCol = false;
			}
		}
	}
	getDatatypeOnChange = function(e){
		if(e.value == "string"){
			this.num_ranges = "";
			this.patternForNumber = "string";
		}else if(e.value == "number"){
			this.patternForNumber = "number";
			this.num_ranges = "";
		}else if(e.value == "boolean"){
			this.patternForNumber = "boolean";
			this.num_ranges = "";
		}
		
	}
	onlyNumberKey(event) {
  	  return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
	}
	ngOnInit() {}
}
// dp.operations@axisbank.com