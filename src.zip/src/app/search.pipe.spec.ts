/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
// import { SearchPipe } from './search.pipe';

xdescribe('SearchPipe', () => {
  it('create an instance', () => {
    // const pipe = new SearchPipe();
    // expect(pipe).toBeTruthy();
  });
});
